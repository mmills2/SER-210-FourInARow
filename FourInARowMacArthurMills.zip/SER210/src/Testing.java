import java.util.ArrayList;
import java.util.Random;

public class Testing {

	public static void main(String[] args) {
		ArrayList<Integer> bestMoves = new ArrayList<Integer>();
		bestMoves.add(4);
		bestMoves.add(3);
		bestMoves.add(2);
		Random rand = new Random();
		System.out.println(rand.nextInt(bestMoves.size()));
		}

}
